Examples of other directory names:
V1I1A - only BOM changes
V1I2 - pin compatible with V1I1, no big changes
V2I1 - not compatible with V1


This is also place for backups. Pack V1I1 Directory, add date and possibly a note:
V1I1 2011 01 10
V1I1 2011 02 21 Schematic Checked