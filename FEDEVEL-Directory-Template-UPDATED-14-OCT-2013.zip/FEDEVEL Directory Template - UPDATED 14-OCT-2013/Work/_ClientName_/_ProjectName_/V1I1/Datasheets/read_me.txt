For components with one datasheet only, these can be place directly here.

For components with more then one datasheet, create a directory, e.g:
Intel
Ethernet