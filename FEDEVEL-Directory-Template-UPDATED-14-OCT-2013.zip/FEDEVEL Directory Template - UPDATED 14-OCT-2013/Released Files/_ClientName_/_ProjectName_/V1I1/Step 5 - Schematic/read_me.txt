Update Schematic Cover Page to RELEASED DD-MMM-YYYY
Place here PDF version of schematic, if possible one for each BOM variant.